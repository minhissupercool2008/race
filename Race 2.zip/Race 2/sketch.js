var path,mainRacer;
var player1,player2,player3;
var pathImg,mainRacer1,mainRacer2;
var 